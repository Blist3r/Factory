    <script src="{{ asset('assets/vendor/global/global.min.js') }}"></script>
	<script src="{{ asset('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js') }}"></script>
	<script src="{{ asset('assets/vendor/chart.js/Chart.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/js/custom.min.js') }}"></script>
	<script src="{{ asset('assets/js/deznav-init.js') }}"></script>

	<!-- Counter Up -->
    <script src="{{ asset('assets/vendor/waypoints/jquery.waypoints.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/jquery.counterup/jquery.counterup.min.js') }}"></script>

	<!-- Apex Chart -->
	{{-- <script src="{{ asset('assets/vendor/apexchart/apexchart.js') }}"></script> --}}

	<!-- Chart piety plugin files -->
	<script src="{{ asset('assets/vendor/peity/jquery.peity.min.js') }}"></script>

	<!-- Dashboard 1 -->
	{{-- <script src="{{ asset('assets/js/dashboard/dashboard-1.js') }}"></script> --}}

    @yield('mySripts')
