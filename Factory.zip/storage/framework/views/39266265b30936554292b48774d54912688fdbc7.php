

<?php $__env->startSection('mySripts'); ?> <script src="<?php echo e(asset('assets/js/clientes.js')); ?>"></script> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Clientes</h4>
                        <button type="button" class="btn btn-success" onclick="LimpiarInput()" data-toggle="modal" data-target="#modalAgregarCliente">Agregar Cliente</button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                            <?php if(session()->has('create')): ?>
                                <div class="alert <?php echo e(session('create') == 1 ? 'alert-success' : 'alert-danger'); ?> alert-dismissible alert-alt fade show">
                                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
                                    </button>
                                    <strong><?php echo e(session('mensaje')); ?>!</strong>
                                </div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible alert-alt fade show">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            

                            <table class="table table-bordered table-striped verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">Nombre del Usuario</th>
                                        <th scope="col">Identificación</th>
                                        <th scope="col">Direccion</th>
                                        <th scope="col">Telefono</th>
                                        <th scope="col">Correo</th>
                                        <th scope="col">Configuracion</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <!-- En la tabla se pone el nombre segun lo digitado en el boton de agregar user -->
                                            <td><?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellido); ?> </td>
                                            <td>  <?php echo e($cliente->identificacion); ?>  </td>
                                            <td>  <?php echo e($cliente->direccion); ?>  </td>
                                            <td>  <?php echo e($cliente->telefono); ?>  </td>
                                            <td>  <?php echo e($cliente->correo); ?>  </td>
                
                                            <td>
                                                <span>
                                                    <a href="javascript:EditarCliente(<?php echo e($cliente->id); ?>)" class="mr-4" data-toggle="tooltip" data-placement="top" title="Edit">
                                                        <i class="fa fa-pencil color-muted"></i>
                                                    </a>
                                                    <a href="javascript:EliminarCliente(<?php echo e($cliente->id); ?>)" data-toggle="tooltip" data-placement="top" title="Close">
                                                        <i class="fa fa-close color-danger"></i>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalAgregarCliente">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Agregar Cliente</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('clientes.create')); ?>" method="post" id="formCrearCliente">
                    <!-- Token para encriptar -->
                    <?php echo csrf_field(); ?>

                    <div class="form-row">
                        <label>Nombre</label>

                        <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Escriba el nombre del operador" required="">
                    </div>

                    <div class="form-row mt-3">
                        <label>Apellido</label>

                        <input type="text" class="form-control" name="apellido" id="apellido" placeholder="Escriba el apellido del operador" required="">
                    </div>

                    <div class="form-row mt-3">
                        <label>Identificacion</label>

                        <input type="number" class="form-control" name="identificacion" id="identificacion" placeholder="Escriba la identificacion del cliente" required="">
                    </div>

                    <div class="form-row mt-3">
                        <label>Direccion</label>

                        <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Escriba la direccion del cliente" >
                    </div>

                    <div class="form-row mt-3">
                        <label>Telefono</label>

                        <input type="number" class="form-control" name="telefono" id="telefono" placeholder="Escriba la direccion del cliente">
                    </div>

                    <div class="form-row mt-3">
                        <label>Correo</label>

                        <input type="email" class="form-control" name="correo" id="correo" placeholder="Escriba la direccion del cliente">
                    </div>

                    <input type="hidden" name="id" id="id" value="">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" onclick="document.getElementById('formCrearCliente').submit()">Guardar</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Factory\Factory\resources\views/configuracion/Cliente/clientes.blade.php ENDPATH**/ ?>