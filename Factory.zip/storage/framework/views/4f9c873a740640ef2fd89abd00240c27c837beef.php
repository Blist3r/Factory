<?php $__env->startSection('myStyles'); ?>
    <link href="<?php echo e(asset('assets/vendor/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/pickadate/themes/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/pickadate/themes/default.date.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mySripts'); ?>
    <script src="<?php echo e(asset('assets/js/reporteventas.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/vendor/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins-init/bs-daterange-picker-init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ventas</h4>
                    </div>
                    <div class="card-body">

                        <div class="row d-flex">
                            <form action="<?php echo e(route('exportar_ventas')); ?>" method="post" class="w-100" style="display: contents;">
                                <?php echo csrf_field(); ?>

                                <div class="col-xl-4 mb-3">
                                    <div class="example">
                                        <input class="form-control input-daterange-datepicker" type="text" name="rango_fechas" id="rango_fechas">
                                    </div>
                                </div>

                                <div class="col-xl-4 mb-3">
                                    <select name="sedes_id" id="sedes_id" class="form-control" onchange="filtrarPorSede(this.value)">
                                        <option value="">Seleccione la sede</option>

                                        <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $selected = \Request::get('sede') == $sede->id ? 'selected' : ''; ?>
                                            <option value="<?php echo e($sede->id); ?>" <?php echo e($selected); ?>><?php echo e($sede->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                               </div>
                               <div>
                                    <button type="submit" class="btn btn-success">Exportar Ventas</button>
                                </div>
                            </form>
                            <div class="ml-3">
                                <button type="button" onclick="cierre()" class="btn btn-success">Cierre</button>
                            </div>
                        </div>

                        <div class="table-responsive">

                            <?php if(session()->has('create')): ?>
                                <div class="alert <?php echo e(session('create') == 1 ? 'alert-success' : 'alert-danger'); ?> alert-dismissible alert-alt fade show">
                                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
                                    </button>
                                    <strong><?php echo e(session('mensaje')); ?>!</strong>
                                </div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible alert-alt fade show">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>


                            <table class="table table-bordered table-striped verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">Venta</th>
                                        <th scope="col">Fecha</th>
                                        <th scope="col">Sede</th>
                                        <th scope="col">Vendedor</th>
                                        <th scope="col">Cliente</th>
                                        <th scope="col">Metodo de Pago</th>
                                        <th scope="col">Total</th>
                                        <th scope="col" class="text-center"> <span>  <i class="fa fa-cog"></i> </span> </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <!-- En la tabla se pone el nombre segun lo digitado en el boton de agregar venta -->
                                            <td> <?php echo e($venta->id); ?> </td>
                                            <td> <?php echo e($venta->fecha); ?> </td>
                                            <td> <?php echo e(App\Models\Sede::find($venta->sedes_id)->nombre); ?> </td>
                                            <td> <?php echo e(App\Models\User::find($venta->users_id)->nombre); ?> <?php echo e(App\Models\User::find($venta->users_id)->apellido); ?></td>
                                            <td> <?php echo e(App\Models\Cliente::find($venta->clientes_id)->nombre); ?> </td>
                                            <td> <?php echo e($venta->metodo_pago); ?> </td>
                                            <td> <?php echo e(number_format($venta->total)); ?> </td>
                                            <td class="text-center">
                                                <span>
                                                    <a href="javascript:MostrarVenta(<?php echo e($venta->id); ?>)" data-toggle="tooltip" data-placement="top" title="Descripcion de Venta">
                                                        <i class="fa fa-eye color-muted"></i>
                                                    </a>
                                                    <a href="javascript:Imprimir(<?php echo e($venta->id); ?>)" data-toggle="tooltip" data-placement="top" title="Imprimir" class="ml-2">
                                                        <i class="fa fa-print"></i>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalMostrarVenta">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ventas</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="contentModalDetalle">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Factory\Factory\resources\views/reportes/ventas.blade.php ENDPATH**/ ?>