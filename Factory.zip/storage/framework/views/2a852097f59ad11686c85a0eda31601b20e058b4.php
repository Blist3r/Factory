<div class="footer">

</div>
<?php /**PATH D:\Factory\Factory\resources\views/layouts/src/footer.blade.php ENDPATH**/ ?>