

<?php $__env->startSection('mySripts'); ?> <script src="<?php echo e(asset('assets/js/productos.js')); ?>"></script> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Productos</h4>
                        <button type="button" class="btn btn-success" onclick="LimpiarInput()" data-toggle="modal" data-target="#modalAgregarProducto">Agregar Producto</button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                            <?php if(session()->has('create')): ?>
                                <div class="alert <?php echo e(session('create') == 1 ? 'alert-success' : 'alert-danger'); ?> alert-dismissible alert-alt fade show">
                                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
                                    </button>
                                    <strong><?php echo e(session('mensaje')); ?>!</strong>
                                </div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible alert-alt fade show">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            

                            <table class="table table-bordered table-striped verticle-middle table-responsive-sm">
                                <thead>
                                    <tr>
                                        <th scope="col">Imagen del Producto</th>
                                        <th scope="col">Nombre del Producto</th>
                                        <th scope="col">Descripción</th>
                                        <th scope="col">Valor</th>
                                        <th scope="col">Categoria</th>
                                        <th scope="col">Configuracion</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <!-- Se agregan los espacios cada dato en la tabla -->
                                        <td> <div class="d-flex align-items-center"><img src=" <?php echo e(asset('storage/'.$producto->imagen)); ?> " class="rounded-lg mr-2" width="80" alt=""></div>  </td>
                                        <td> <?php echo e($producto->nombre); ?> </td>
                                        <td> <?php echo e($producto->descripcion); ?> </td>
                                        <td> $<?php echo e(number_format($producto->valor)); ?> </td>
                                        <td>  <?php echo e(App\Models\Categoria::find($producto->categorias_id)->nombre); ?>  </td>

                                            <td>
                                                <span>
                                                    <a href="javascript:EditarProducto(<?php echo e($producto->id); ?>)" class="mr-4" data-toggle="tooltip" data-placement="top" title="Edit">
                                                        <i class="fa fa-pencil color-muted"></i>
                                                    </a>
                                                    <a href="javascript:EliminarProducto(<?php echo e($producto->id); ?>)" data-toggle="tooltip" data-placement="top" title="Close">
                                                        <i class="fa fa-close color-danger"></i>
                                                    </a>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalAgregarProducto">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Agregar Producto</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('productos.create')); ?>" method="post" id="formCrearProducto" enctype="multipart/form-data">
                    <!-- Token para encriptar -->
                    <?php echo csrf_field(); ?>
                    <label>Imagen</label>
                    <div class="input-group mt-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Subir la imagen</span>
                        </div>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" name="imagen" id="imagen">
                                 <label class="custom-file-label">Elegir el archivo </label>
                        </div>
                    </div>
                    
                    <div class="form-row mt-3">
                        <label>Nombre</label>

                        <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Escriba el nombre del producto" required="">
                    </div>

                    <div class="form-row mt-3">
                        <label>Descripción</label>

                        <input type="longText" class="form-control" name="descripcion" id="descripcion" placeholder="Escriba la descripcion del producto" required="">
                    </div>

                    <div class="form-row mt-3">
                        <label>Valor</label>

                        <input type="integer" class="form-control" name="valor" id="valor" placeholder="Escriba el valor del producto" required="">
                    </div>

                    <div class="form-row mt-3"> 
                        <label>Categorias</label>

                        <select name="categorias_id" id="categorias_id" class="form-control" required>
                            <option value="">Seleccione la categoria</option>
                            <!-- Se crea un foreaach, para que busque en el arreglo los valores que hay y los vuelva un valor. -->
                            <?php $__currentLoopData = App\Models\Categoria::orderBy('nombre', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <input type="hidden" name="id" id="id" value="">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" onclick="document.getElementById('formCrearProducto').submit()">Guardar</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Factory\Factory\resources\views/configuracion/Producto/productos.blade.php ENDPATH**/ ?>