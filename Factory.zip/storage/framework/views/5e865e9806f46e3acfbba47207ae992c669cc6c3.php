    <script src="<?php echo e(asset('assets/vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/deznav-init.js')); ?>"></script>

	<!-- Counter Up -->
    <script src="<?php echo e(asset('assets/vendor/waypoints/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/jquery.counterup/jquery.counterup.min.js')); ?>"></script>

	<!-- Apex Chart -->
	

	<!-- Chart piety plugin files -->
	<script src="<?php echo e(asset('assets/vendor/peity/jquery.peity.min.js')); ?>"></script>

	<!-- Dashboard 1 -->
	

    <?php echo $__env->yieldContent('mySripts'); ?>
<?php /**PATH D:\Factory\Factory\resources\views/layouts/src/scripts.blade.php ENDPATH**/ ?>